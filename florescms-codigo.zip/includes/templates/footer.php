
<footer class="site-footer clearfix">
    <div class="contenedor clearfix">
        <div class="footer-informacion">
            <p>Espectaculares flores para ti.</p>
        </div>
        <div class="menu">
            <h3>REDES <span>SOCIALES</span></h3>
            <nav class="redes-sociales">
                <a href="#"><i class="fab fa-facebook-f"></i></a>
                <a href="#"><i class="fab fa-instagram"></i></a>
              </nav>
        </div>
    </div>
    <p class="copyright">FloresDelDia - Todos los derechos Reservados 2019 &copy;</p>
  </footer>



  
  <script src="js/vendor/modernizr-3.6.0.min.js"></script>

    <script src="js/plugins.js"></script>
    <script src="js/main.js"></script>
     
  
  <!-- Include all compiled plugins (below), or include individual files as needed --> 
  <!-- <script src="js/bootstrap.js"></script> -->
  <script src="js/.js"></script>
  
    <!-- Google Analytics: change UA-XXXXX-Y to be your site's ID. -->
    <script>
      window.ga = function () { ga.q.push(arguments) }; ga.q = []; ga.l = +new Date;
      ga('create', 'UA-XXXXX-Y', 'auto'); ga('send', 'pageview')
    </script>
    <script src="https://www.google-analytics.com/analytics.js" async defer></script>
  </body>
  </html>