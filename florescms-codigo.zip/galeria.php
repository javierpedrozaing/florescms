<?php include_once 'includes/templates/header2.php';?>

<!--CALENDARIO-->
<!--------------------------------------------------------------------------------->
<div class="linea contenedor">
    <p></p>
  </div>
<!--------------------------------------------------------------------------------->

<section  class="seccion">
    <h2>GALERIA</h2>
    <div class="contenedor">
        <br>
       <!-- LightWidget WIDGET --><script src="https://cdn.lightwidget.com/widgets/lightwidget.js"></script><iframe src="//lightwidget.com/widgets/a879e6b10a3458abb3ec3aac3d5b6f78.html" scrolling="no" allowtransparency="true" class="lightwidget-widget" style="width:100%;border:0;overflow:hidden;"></iframe>

    </section>


<?php include_once 'includes/templates/footer.php';?>