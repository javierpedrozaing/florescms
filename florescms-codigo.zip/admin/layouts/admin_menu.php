<ul>
  <li>
    <a href="home.php">
      <i class="glyphicon glyphicon-home"></i>
      <span>Panel de control</span>
    </a>
  </li>
  <li>
    <a href="users.php" class="submenu-toggle">
      <i class="glyphicon glyphicon-user"></i>
      <span>Usuarios</span>
    </a>
  
  </li>
  <li>
    <a href="categorie.php" >
      <i class="glyphicon glyphicon-indent-left"></i>
      <span>Categorias</span>
    </a>
  </li>
  <li>
    <a href="media.php" >
      <i class="glyphicon glyphicon-picture"></i>
      <span>Imagenes</span>
    </a>
  </li>
  <li>
    <a href="product.php" class="submenu-toggle">
      <i class="glyphicon glyphicon-th-large"></i>
      <span>Productos</span>
    </a>    
  </li>

</ul>
