<?php include_once 'includes/templates/header2.php';?>
<!--------------------------------------------------------------------------------->
<div class="linea contenedor">
    <p></p>
  </div>
<!--------------------------------------------------------------------------------->

<section  class="seccion">
    <h2>BLOG</h2>
    <div class="contenedor">
        <br>

    </section>


<?php include_once 'includes/templates/footer.php';?>